package idfinder;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class IdFinderController implements Initializable {

	@FXML
	private TextField nameFind, phoneFind;
	@FXML
	private Button btnFind, btnCancel;
	String strName, strPhone; // 텍스트필드 값 변수 담아줄 것


	@Override
	public void initialize(URL location, ResourceBundle resources) {

		// 찾기 버튼 눌렀을 때 텍스트 필드 값 String에 저장
		btnFind.setOnAction(event -> {
			strName = nameFind.getText();
			strPhone = phoneFind.getText();
		

			System.out.println(strName); // 생략가능(확인절차)
			System.out.println(strPhone); // 생략가능(확인절차)

			handleCustom();
		});

		// 취소, 창 닫기
		btnCancel.setOnAction(event -> {
			Stage stage = (Stage) btnCancel.getScene().getWindow();
			stage.close();
		});

	}

	private void handleCustom() {
		String dbName, dbPhone, dbId; // 데이터베이스에 있는 이름 번호 값 가져와서
		dbName = "권민규";
		dbPhone = "010-4445-6794"; // 비교하기 위한 임의의 값
		dbId = "kmk0511";

		

		if (strName.equals(dbName) && strPhone.equals(dbPhone)) {
			
			try {
				
				Parent parent = FXMLLoader.load(getClass().getResource("idSuccessCustom.fxml"));
				Stage stage = new Stage(StageStyle.UTILITY);
				stage.initModality(Modality.APPLICATION_MODAL);
				
				// parent 안에 id 찾아서 객체 만들고 텍스트 넣어주기
				Label lblName = (Label)parent.lookup("#lblName"); 
				lblName.setText(dbName);
				
				Label lblId = (Label)parent.lookup("#lblId");
				lblId.setText(dbId);
				
				Button btnOk = (Button)parent.lookup("#btnOk");
				
				stage.setScene(new Scene(parent));
				stage.setResizable(false); // 사이즈 조절 불가능
				stage.show();
				
				btnOk.setOnAction(event->{
					stage.close();
				});
				
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		} else {
			
			try {
				
				Parent parent = FXMLLoader.load(getClass().getResource("idFailCustom.fxml"));
				Stage stage = new Stage(StageStyle.UTILITY);
				stage.initModality(Modality.APPLICATION_MODAL);
				
				Button btnOk = (Button)parent.lookup("#btnOk");
				
				stage.setScene(new Scene(parent));
				stage.setResizable(false); // 사이즈 조절 불가능
				stage.show();
				
				btnOk.setOnAction(event->{
					stage.close();
				});
				
				
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}
	}

}
