package Login;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import empVO.EmpVO;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class LoginController implements Initializable {
	@FXML
	Button btnLogin, btnJoin, btnIdFinder, btnPWFinder, btnExit;
	@FXML
	TextField idField;
	@FXML
	PasswordField pwField;
	String id = "";
	String pw = "";
	Stage primaryStage;

	@Override
	public void initialize(URL location, ResourceBundle resources) {

		// 로그인버튼
		btnLogin.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				id = idField.getText();
				pw = pwField.getText();

				EmpVO e = new EmpVO(id, pw);
				System.out.println(e);
				boolean s = true;
				if (s) {
					System.out.println("LoginSuccese");
					if(id.equals("Manager")) {
						try {
							Parent appMain = FXMLLoader.load(getClass().getResource("../MainBanner/home.fxml"));
							Stage stage = new Stage(StageStyle.DECORATED);
							Stage closeS = (Stage) btnLogin.getScene().getWindow();
							stage.setScene(new Scene(appMain));
							stage.show();
							closeS.close();
							
						} catch (IOException e1) {
							
							e1.printStackTrace();
							
						}
					}else {
						
					}
					

				} else {
					System.out.println("LoginFailed");
					Stage stage = new Stage(StageStyle.UTILITY);
					Scene scene = null;
					try {
						Parent root = FXMLLoader.load(getClass().getResource("../Login/LoginFail.fxml"));
						scene = new Scene(root);
						Button btnOk = (Button) root.lookup("#btnOk");
						stage.initModality(Modality.WINDOW_MODAL);

						stage.initOwner(btnIdFinder.getScene().getWindow());
						stage.setScene(scene);
						stage.show();

						btnOk.setOnAction(event1 -> {
							System.out.println("close");

							stage.close();
						});
					} catch (IOException e1) {
						e1.printStackTrace();
					}
				}

			}
		});

		// 회원가입버튼 클릭시 -> 회원가입 창 띄움
		btnJoin.setOnAction(e -> {
			System.out.println("JoinButtonClick");
			Stage stage = new Stage(StageStyle.UTILITY);
			Scene scene = null;
			try {
				Parent root = FXMLLoader.load(getClass().getResource("../Login/join.fxml"));
				scene = new Scene(root);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			stage.initModality(Modality.WINDOW_MODAL);
			stage.initOwner(btnIdFinder.getScene().getWindow());
			stage.setScene(scene);
			stage.show();

		});

		// 아이디 찾기 버튼 클릭시 -> 창 띄움
		btnIdFinder.setOnAction(e -> {
			System.out.println("IDFinderClick");
			Stage stage = new Stage(StageStyle.UTILITY);
			Scene scene = null;
			try {
				Parent root = FXMLLoader.load(getClass().getResource("../idfinder/idFinder.fxml"));
				scene = new Scene(root);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			stage.initModality(Modality.WINDOW_MODAL);
			stage.initOwner(btnIdFinder.getScene().getWindow());
			stage.setScene(scene);
			stage.show();
		});

		// 비밀번호 찾기 번튼 클릭시 ->
		btnPWFinder.setOnAction(e -> {
			System.out.println("PwFinderClick");
			Stage stage = new Stage(StageStyle.UTILITY);
			Scene scene = null;
			try {
				Parent root = FXMLLoader.load(getClass().getResource("../pwfinder/pwFinder.fxml"));
				scene = new Scene(root);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			stage.initModality(Modality.WINDOW_MODAL);
			stage.initOwner(btnIdFinder.getScene().getWindow());
			stage.setScene(scene);
			stage.show();
		});

		// 종료버튼
		btnExit.setOnAction(e -> {
			System.out.println("PwFinderClick");
			Stage stage = new Stage(StageStyle.UNDECORATED);
			Scene scene = null;
			try {
				Parent root = FXMLLoader.load(getClass().getResource("../Login/exit.fxml"));
				scene = new Scene(root);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			stage.initModality(Modality.WINDOW_MODAL);
			stage.initOwner(btnIdFinder.getScene().getWindow());
			stage.setScene(scene);
			stage.show();
		});

		// 로그인 실패

	}

}
