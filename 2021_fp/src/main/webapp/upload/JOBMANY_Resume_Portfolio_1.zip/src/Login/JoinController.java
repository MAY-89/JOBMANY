package Login;

import java.net.URL;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.ResourceBundle;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class JoinController implements Initializable {
	@FXML TextField idField, nameField, yearField, dayField, adressField,mobMidField, mobLastField, phoneMidField, phoneLastField, emailIdField, emailField;
	@FXML PasswordField pwField, pwcField;
	@FXML ComboBox<String> monthBox, mobFirstBox, phoneBox, emailBox;
	@FXML Button btnIdc, btnOk, btnCancel;
	@FXML ImageView pwcImg;
	@FXML DatePicker datePicker;
	
	
	private String id, pw, name, date, adress, mobileNumber, phone, email;
	
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		//콤보박스 추가
		ObservableList<String> monthList = FXCollections.observableArrayList("1월","2월","3월","4월","5월","6월","7월","8월","9월","10월","11월","12월");
		ObservableList<String> mobileList = FXCollections.observableArrayList("010","017","018","직접입력");
		ObservableList<String> phoneList = FXCollections.observableArrayList("02(서울)","051(부산)","053(대구)","032(인천)","062(광주)","042(대전)","052(울산)","044(세종)","031(경기)","033(강원)","043(충북)","041(충남)","063(전북)","061(전남)","054(경북)","055(경남)","064(제주)");
		ObservableList<String> emailList = FXCollections.observableArrayList("네이버","다음","네이트","구글","직접입력");
		monthBox.setItems(monthList);mobFirstBox.setItems(mobileList);phoneBox.setItems(phoneList);emailBox.setItems(emailList);
		
		//아이디 중복확인
				btnIdc.setOnAction(e->{
					if(!idField.getText().equals(null)) {
						idField.setStyle("-fx-background-color:rgba(255,0,0,0.3)");	
					}else {
						idField.setStyle("-fx-background-color:null");
						id = idField.getText();
					}
					System.out.println(id);
				});
				
		
		//비밀번호 다르면 에러이미지로 변경
		pwcField.textProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
				
				if(!newValue.equals(pwField.getText().toString())) {
					Image errImg = new Image(getClass().getResource("img/x.png").toString());
					pwcImg.setImage(errImg);
				}else{
					Image checkImg = new Image(getClass().getResource("img/c.png").toString());
					pwcImg.setImage(checkImg);
					pw = pwcField.getText();
					System.out.println(pw);
				}
			}
		});
		
		//이름값받아오기
		nameField.textProperty().addListener(l->{
			name = nameField.getText();
			System.out.println(name);
		});
		
		//생년월일 설정
		Calendar cal = Calendar.getInstance();
		int data = cal.get(Calendar.YEAR);
		LocalDate lDate = LocalDate.of(data-30, 1, 1);
		datePicker.setValue(lDate);
		datePicker.valueProperty().addListener(new ChangeListener<LocalDate>() {

			@Override
			public void changed(ObservableValue<? extends LocalDate> observable, LocalDate oldValue,LocalDate newValue) {
				date = datePicker.getValue().toString();
				System.out.println(date);
				
			}
		});
		
		//주소값 받아오기
		adressField.textProperty().addListener(new ChangeListener<String>() {

			@Override
			public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
				adress = adressField.getText();
				System.out.println(adress);
			}
		});
		
		
		//핸드폰 번호
		 mobFirstBox.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {

			@Override
			public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
				
				//핸드폰 가운데자리
				mobMidField.textProperty().addListener(new ChangeListener<String>() {
					String first = newValue;
					
					@Override
					public void changed(ObservableValue<? extends String> observable, String oldValue,
							String newValue) {
						
						//핸드폰 마지막
						mobLastField.textProperty().addListener(new ChangeListener<String>() {
							String mid = newValue;
							
							@Override
							public void changed(ObservableValue<? extends String> observable, String oldValue,
									String newValue) {
								
								mobileNumber = first+mid+newValue;
								System.out.println(mobileNumber);
								
							}
						});
					}
				});
				
			}
		});;
		
		//핸드폰번호 자리수 4자리 이하
		mobMidField.textProperty().addListener(new ChangeListener<String>() {

			@Override
			public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
				if(newValue.length()>4) {
					mobMidField.setStyle("-fx-background-color:rgba(255,0,0,0.3)");
				}else {
					mobMidField.setStyle(null);
				}
				
			}
		});
		mobLastField.textProperty().addListener(new ChangeListener<String>() {

			@Override
			public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
				if(newValue.length()>4) {
					mobLastField.setStyle("-fx-background-color:rgba(255,0,0,0.3)");
				}else {
					mobLastField.setStyle(null);
				}
				
			}
		});
		
		
		
		//전화번호
		phoneBox.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {

			@Override
			public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
				String[] phoneAry = phoneBox.getSelectionModel().getSelectedItem().split("\\(");
				String phoneF = phoneAry[0];
				System.out.println(phoneF);
				phoneLastField.textProperty().addListener(new ChangeListener<String>() {

					@Override
					public void changed(ObservableValue<? extends String> observable, String oldValue,
							String newValue) {
						phone = phoneF+phoneMidField.getText()+phoneLastField.getText();
						System.out.println(phone);
					}
					
				});
				
			}
		});
		
		//전화번호 자리수 4자리 이하
				phoneMidField.textProperty().addListener(new ChangeListener<String>() {

					@Override
					public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
						if(newValue.length()>3) {
							phoneMidField.setStyle("-fx-background-color:rgba(255,0,0,0.3)");
						}else {
							phoneMidField.setStyle(null);
						}
						
					}
				});
				phoneLastField.textProperty().addListener(new ChangeListener<String>() {

					@Override
					public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
						if(newValue.length()>4) {
							phoneLastField.setStyle("-fx-background-color:rgba(255,0,0,0.3)");
						}else {
							phoneLastField.setStyle(null);
						}
						
					}
				});
		
				
		//email설정
		emailBox.getSelectionModel().selectedIndexProperty().addListener(new ChangeListener<Number>() {

			@Override
			public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
				switch(newValue.intValue()){
				//네이버
				case 0: 
					email = emailIdField.getText()+"@naver.com";
					emailBox.setPrefWidth(150);
					emailBox.setLayoutX(158);emailBox.setLayoutY(500);
					System.out.println(email);
					break;
				//다음	
				case 1:
					email = emailIdField.getText()+"@daum.net";
					emailBox.setPrefWidth(150);
					emailBox.setLayoutX(158);emailBox.setLayoutY(500);
					System.out.println(email);
					break;
				//네이트	
				case 2:
					email = emailIdField.getText()+"@nate.com";
					emailBox.setPrefWidth(150);
					emailBox.setLayoutX(158);emailBox.setLayoutY(500);
					System.out.println(email);
					break;
				//구글	
				case 3:
					email = emailIdField.getText()+"@gmail.com";
					emailBox.setPrefWidth(150);
					emailBox.setLayoutX(158);emailBox.setLayoutY(500);
					System.out.println(email);
					break;
				//직접입력
				case 4:
					emailBox.setPrefWidth(1);
					emailBox.setLayoutX(310);emailBox.setLayoutY(500);
					emailField.textProperty().addListener(new ChangeListener<String>() {

						@Override
						public void changed(ObservableValue<? extends String> observable, String oldValue,
								String newValue) {
							email = emailIdField.getText()+"@"+emailField.getText();
							System.out.println(email);
						}
					});;
					break;
				}
			}
		});
		
		
	
		
		//등록버튼
		btnOk.setOnAction(e->{
					
		});
				
		//취소
		btnCancel.setOnAction(e->{
			Stage stage = (Stage) btnCancel.getScene().getWindow();
			stage.close();
		});
		
		
	}

}

