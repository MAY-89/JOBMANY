package MainBanner;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import empVO.EmpVO;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class MainController implements Initializable {

	@FXML
	private Button btn1, btn2, btn3, btn4;
	@FXML
	private AnchorPane s1, s2, s3, s4;
	@FXML
	Label lbl1, lbl2, lbl3, lbl4;
	@FXML
	private StackPane stackPane;
	@FXML
	private TableView<ManageVO> manageTable; // 민규 추가
	@FXML
	private Button manageBtnModify, manageBtnRemove; // 민규 추가

	String cellFirst2, phoneFirst2, emailLast2; // 민규 추가
	Stage primaryStage;
	EmpVO empvoManage; // 민규 추가
	ObservableList<String> manageComboCellModify = FXCollections.observableArrayList("010", "011", "016", "017", "018",
			"019"); // 민규 추가
	ObservableList<String> manageComboPhoneModify = FXCollections.observableArrayList("02", "051", "053", "032", "062",
			"042", "052", "044", "031", "033", "043", "041", "063", "061", "054", "055", "064"); // 민규 추가
	ObservableList<String> manageComboEmailModify = FXCollections.observableArrayList("네이버", "다음", "네이트", "구글"); // 민규
																													// 추가
	ObservableList<ManageVO> manageTableView; // 민규 추가
	String manageName; // 민규 추가 
	ManageVO manageVO; // 

	@Override
	public void initialize(URL l, ResourceBundle r) {

		s1.setVisible(true);
		s2.setVisible(false);
		s3.setVisible(false);
		s4.setVisible(false);

		// 버튼 1번 이벤트 (홈)
		btn1.setOnAction((event) -> {
			home();
		});
		// 버튼 2번 이벤트(스케줄)
		btn2.setOnAction((event) -> {
			schedule();
		});
		// 버튼 3번 이벤트 (휴가)
		btn3.setOnAction((event) -> {
			vacation();
		});
		// 버튼 4번 이벤트 (직원관리)
		btn4.setOnAction((event) -> {
			manage();
		});
		
		
	}

	public void home() {
		s1.setVisible(true);
		s2.setVisible(false);
		s3.setVisible(false);
		s4.setVisible(false);

		btn1.setStyle("-fx-background-color:darkgray");
		btn2.setStyle("-fx-background-color:null");
		btn3.setStyle("-fx-background-color:null");
		btn4.setStyle("-fx-background-color:null");

	}

	private void schedule() {
		s1.setVisible(false);
		s2.setVisible(true);
		s3.setVisible(false);
		s4.setVisible(false);

		btn1.setStyle("-fx-background-color:null");
		btn2.setStyle("-fx-background-color:darkgray");
		btn3.setStyle("-fx-background-color:null");
		btn4.setStyle("-fx-background-color:null");
	}

	private void vacation() {
		s1.setVisible(false);
		s2.setVisible(false);
		s3.setVisible(true);
		s4.setVisible(false);

		btn1.setStyle("-fx-background-color:null");
		btn2.setStyle("-fx-background-color:null");
		btn3.setStyle("-fx-background-color:darkgray");
		btn4.setStyle("-fx-background-color:null");
	}

	// 민규 추가
	private void manage() {
		s1.setVisible(false);
		s2.setVisible(false);
		s3.setVisible(false);
		s4.setVisible(true);

		btn1.setStyle("-fx-background-color:null");
		btn2.setStyle("-fx-background-color:null");
		btn3.setStyle("-fx-background-color:null");
		btn4.setStyle("-fx-background-color:darkgray");

		// for(받아올 데이터 있을 때 까지) {
		/*
		 * manageTableView = FXCollections .observableArrayList(new ManageVO(1, "권민규",
		 * "ToTheHell", "010-4445-6794", "부산시"));
		 * 
		 * manageTable.setItems(manageTableView);
		 */
		// }
		
		
		ObservableList<ManageVO> manglist = FXCollections.observableArrayList(new ManageVO(1, "권민규", "kmk", "010-1111-1111", "부산"));
		manageTable.getColumns().get(0).setCellValueFactory(new PropertyValueFactory<>("empNo"));
		manageTable.getColumns().get(1).setCellValueFactory(new PropertyValueFactory<>("ename"));
		manageTable.getColumns().get(2).setCellValueFactory(new PropertyValueFactory<>("eid"));
		manageTable.getColumns().get(3).setCellValueFactory(new PropertyValueFactory<>("ecell"));
		manageTable.getColumns().get(4).setCellValueFactory(new PropertyValueFactory<>("eaddress"));
		
		
		manageTable.setItems(manglist);
		manglist.add(new ManageVO(2,"장인제","JIJ", "010-1234-5678","양산"));
		
		manageTable.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<ManageVO>() {

			@Override
			public void changed(ObservableValue<? extends ManageVO> observable, ManageVO oldValue, ManageVO newValue) {
				
				manageVO = newValue;
			}
		});
		
		
		// 민규 추가, 직원관리 삭제버튼
		manageBtnRemove.setOnAction(event -> {
			
			manglist.remove(manageVO);
			
			
		});

		// 민규 추가, 직원관리 수정버튼 (데이터베이스에서 기본적으로 값 불러와야함)
		manageBtnModify.setOnAction(event -> {
			
			
			
			
			try {
				Parent parent = FXMLLoader.load(getClass().getResource("manageModify.fxml"));
				Stage stage = new Stage(StageStyle.UTILITY);
				stage.initModality(Modality.APPLICATION_MODAL);
				stage.setScene(new Scene(parent));
				stage.setResizable(false);
				stage.show();
				
				TextField Mname = (TextField) parent.lookup("#manageTxtNameModify");
				Mname.setText(manageVO.getEname());
				
				Button manageBtnOkModify = (Button) parent.lookup("#manageBtnOkModify");
				Button manageBtnCancelModify = (Button) parent.lookup("#manageBtnCancelModify");

				DatePicker manageDateModify = (DatePicker) parent.lookup("#manageDateModify");

				ComboBox<String> cellFirst = (ComboBox<String>) parent.lookup("#manageComboCellModify");
				cellFirst.setItems(manageComboCellModify);

				cellFirst.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {

					@Override
					public void changed(ObservableValue<? extends String> observable, String oldValue,
							String newValue) {
						cellFirst2 = newValue;
					}
				});

				ComboBox<String> phoneFirst = (ComboBox<String>) parent.lookup("#manageComboPhoneModify");
				phoneFirst.setItems(manageComboPhoneModify);

				phoneFirst.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {

					@Override
					public void changed(ObservableValue<? extends String> observable, String oldValue,
							String newValue) {

						phoneFirst2 = newValue;

					}

				});

				ComboBox<String> emailLast = (ComboBox<String>) parent.lookup("#manageComboEmailModify");
				emailLast.setItems(manageComboEmailModify);

				emailLast.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {

					@Override
					public void changed(ObservableValue<? extends String> observable, String oldValue,
							String newValue) {

						emailLast2 = newValue;

					}

				});

				manageBtnOkModify.setOnAction(event1 -> {
					empvoManage = new EmpVO();
					empvoManage.setName(((TextField) parent.lookup("#manageTxtNameModify")).getText());
					empvoManage.setAdress(((TextField) parent.lookup("#manageTxtAddressModify")).getText());
					empvoManage.setDate(manageDateModify.getValue().toString());

					TextField cellMid = (TextField) parent.lookup("#manageTxtCellMidModify");
					TextField cellLast = (TextField) parent.lookup("#manageTxtCellLastModify");
					String manageCellModify = cellFirst2 + cellMid.getText() + cellLast.getText();
					empvoManage.setMobileNumber(manageCellModify);

					TextField phoneMid = (TextField) parent.lookup("#manageTxtPhoneMidModify");
					TextField phoneLast = (TextField) parent.lookup("#manageTxtPhoneLastModify");
					String managePhoneModify = phoneFirst2 + phoneMid.getText() + phoneLast.getText();
					empvoManage.setPhone(managePhoneModify);

					TextField emailFirst = (TextField) parent.lookup("#manageTxtEmailModify");
					String manageEmailModify = emailFirst.getText() + emailLast2;
					empvoManage.setEmail(manageEmailModify);

					/*
					 * System.out.println(empvoManage.getName());
					 * System.out.println(empvoManage.getAdress());
					 * System.out.println(empvoManage.getDate());
					 * System.out.println(empvoManage.getMobileNumber());
					 * System.out.println(empvoManage.getPhone());
					 * System.out.println(empvoManage.getEmail());
					 */

					stage.close();

				});

				manageBtnCancelModify.setOnAction(event1 -> {
					stage.close();
				});

			} catch (IOException e) {
			}

		});

	}
}
