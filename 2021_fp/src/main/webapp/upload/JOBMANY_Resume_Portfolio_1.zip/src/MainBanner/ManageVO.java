package MainBanner;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class ManageVO {

	private SimpleIntegerProperty empNo;
	private SimpleStringProperty ename;
	private SimpleStringProperty eid;
	private SimpleStringProperty ecell;
	private SimpleStringProperty eaddress;
	
	
	public ManageVO() {
		
	}
	
	public ManageVO(int empNo, String eName, String eid, String ecell, String eaddress) {
		this.empNo = new SimpleIntegerProperty(empNo);
		this.ename = new SimpleStringProperty(eName);
		this.eid = new SimpleStringProperty(eid);
		this.ecell = new SimpleStringProperty(ecell);
		this.eaddress = new SimpleStringProperty(eaddress);
	}

	public int getEmpNo() {
		System.out.println("getEmpNo");
		return empNo.get();
	}

	public void setEmpNo(int empNo) {
		this.empNo.set(empNo);
	}

	public String getEname() {
		System.out.println("geteName");
		return ename.get();
	}

	public void setEname(String eName) {
		this.ename.set(eName);
	}

	public String getEid() {
		return eid.get();
	}

	public void setEid(String eid) {
		this.eid.set(eid);
	}

	public String getEcell() {
		return ecell.get();
	}

	public void setEcell(String ecell) {
		this.ecell.set(ecell);;
	}

	public String getEaddress() {
		return eaddress.get();
	}

	public void setEaddress(String eaddress) {
		this.eaddress.set(eaddress);
	}

	@Override
	public String toString() {
		return "ManageVO [empNo=" + empNo + ", eName=" + ename + ", eid=" + eid + ", ecell=" + ecell + ", eaddress="
				+ eaddress + "]";
	}

}
