package pwfinder;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class PwFinderController implements Initializable {

	@FXML private TextField idFind, nameFind, phoneFind;
	@FXML private Button btnFind, btnCancel;
	String strId, strName, strPhone;   // 텍스트필드 값 변수 담아줄 것
	
	@Override
	public void initialize(URL u, ResourceBundle r) {
		
		// 찾기 버튼 눌렀을 때 텍스트 필드 값 String에 저장
		btnFind.setOnAction(event->{
			strId = idFind.getText();
			strName = nameFind.getText();
			strPhone = phoneFind.getText();
			
			
			System.out.println(strId);
			System.out.println(strName);
			System.out.println(strPhone);
			
			handleCustom();
			
			
		});
		
		
		// 취소, 창 닫기
		btnCancel.setOnAction(event->{
			Stage stage = (Stage)btnCancel.getScene().getWindow();
			stage.close();
		});

	}
	
	
	
	private void handleCustom() {
		String dbName, dbPhone, dbId, dbPw; // 데이터베이스에 있는 이름 번호 값 가져와서
		dbName = "권민규";
		dbPhone = "010-4445-6794"; // 비교하기 위한 임의의 값
		dbId = "kmk0511";
		dbPw = "0511";

		

		if (strName.equals(dbName) && strPhone.equals(dbPhone) && strId.equals(dbId)) {
			
			try {
				
				Parent parent = FXMLLoader.load(getClass().getResource("pwSuccessCustom.fxml"));
				Stage stage = new Stage(StageStyle.UTILITY);
				stage.initModality(Modality.APPLICATION_MODAL);
				
				// parent 안에 id 찾아서 객체 만들고 텍스트 넣어주기
				Label lblId = (Label)parent.lookup("#lblId"); 
				lblId.setText(dbId);
				
				Label lblPw = (Label)parent.lookup("#lblPw");
				lblPw.setText(dbPw);
				
				Button btnOk = (Button)parent.lookup("#btnOk");
				
				stage.setScene(new Scene(parent));
				stage.setResizable(false); // 사이즈 조절 불가능
				stage.show();
				
				btnOk.setOnAction(event->{
					stage.close();
				});
				
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		} else {
			
			try {
				
				Parent parent = FXMLLoader.load(getClass().getResource("pwFailCustom.fxml"));
				Stage stage = new Stage(StageStyle.UTILITY);
				stage.initModality(Modality.APPLICATION_MODAL);
				
				Button btnOk = (Button)parent.lookup("#btnOk");
				
				stage.setScene(new Scene(parent));
				stage.setResizable(false); // 사이즈 조절 불가능
				stage.show();
				
				btnOk.setOnAction(event->{
					stage.close();
				});
				
				
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}
	}

}
