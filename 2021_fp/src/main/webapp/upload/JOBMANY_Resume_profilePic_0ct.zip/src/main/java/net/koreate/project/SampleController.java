package net.koreate.project;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class SampleController {
	
	@RequestMapping("list")
	public String list() {
		return "list";
	}
	
	@RequestMapping("plus")
	public String plus() {
		return "plus";
	}
	
	@RequestMapping("write")
	public String write() {
		return "write";
	}
	
	@RequestMapping("subMain")
	public String subMain() {
		return "subMain";
	}
	
	@RequestMapping("paperMain")
	public String paperMain() {
		return "paperMain";
	}
	
	@RequestMapping("paperWrite")
	public String paperWrite() {
		return "paperWrite";
	}
	
	@RequestMapping("allSearch")
	public String allSearch() {
		return "allSearch";
	}
}
